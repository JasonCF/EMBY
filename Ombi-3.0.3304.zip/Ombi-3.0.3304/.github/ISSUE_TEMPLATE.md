<!--- 

!! Please use the Support / bug report template, otherwise we will close the Github issue !!

Version 2.X is not supported anymore. Please don't open a issue for the 2.x version.
See https://github.com/tidusjar/Ombi/issues/1455 for more information.

(Pleas submit a feature request over here: http://feathub.com/tidusjar/Ombi) 


--->

#### Ombi build Version:

V 3.0.XX

#### Update Branch:

Open Beta

#### Media Sever:

Plex/Emby

#### Media Server Version:

<!-- If appropriate --->

#### Operating System:

(Place text here)


#### Ombi Applicable Logs (from `/logs/` directory or the Admin page):

```

(Logs go here. Don't remove the ' tags for showing your logs correctly. Please make sure you remove any personal information from the logs)

```

#### Problem Description:

(Place text here)

#### Reproduction Steps:

Please include any steps to reproduce the issue, this the request that is causing the problem etc.
