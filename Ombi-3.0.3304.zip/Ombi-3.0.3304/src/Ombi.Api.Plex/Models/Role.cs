namespace Ombi.Api.Plex.Models
{
    public class Role
    {
        public string tag { get; set; }
    }
}