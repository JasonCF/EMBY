﻿using System.Collections.Generic;

namespace Ombi.Api.Plex.Models
{
    public class Roles
    {
        public List<object> roles { get; set; }
    }
}