﻿namespace Ombi.Api.Plex.Models
{
    public class UserRequest
    {
        public string login { get; set; }
        public string password { get; set; }
    }
}