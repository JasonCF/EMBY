﻿using System;
using System.Text;

namespace Ombi.Api.Plex.Models
{
    public class PlexAuthentication
    {
        public User user { get; set; }
    }
}
