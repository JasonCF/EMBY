﻿namespace Ombi.Api.Plex.Models.Status
{
    public class Directory
    {
        public int count { get; set; }
        public string key { get; set; }
        public string title { get; set; }
    }
}