namespace Ombi.Api.Plex.Models
{
    public class Genre
    {
        public string tag { get; set; }
    }
}