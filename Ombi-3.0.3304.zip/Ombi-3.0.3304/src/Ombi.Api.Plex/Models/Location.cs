﻿namespace Ombi.Api.Plex.Models
{
    public class Location
    {
        public int id { get; set; }
        public string path { get; set; }
    }
}