﻿namespace Ombi.Api.Plex.Models
{
    public class Director
    {
        public int id { get; set; }
        public string filter { get; set; }
        public string tag { get; set; }
    }
}