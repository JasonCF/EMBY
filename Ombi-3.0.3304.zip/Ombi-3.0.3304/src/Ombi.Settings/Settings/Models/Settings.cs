﻿namespace Ombi.Settings.Settings.Models
{
    public class Settings
    {
        public int Id { get; set; }
    }
}