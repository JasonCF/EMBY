﻿namespace Ombi.Settings.Settings.Models.Notifications
{
    public class MobileNotificationSettings : Settings
    {
        
    }
}