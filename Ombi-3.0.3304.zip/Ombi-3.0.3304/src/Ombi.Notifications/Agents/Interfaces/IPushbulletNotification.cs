﻿namespace Ombi.Notifications.Agents
{
    public interface IPushbulletNotification : INotification
    {
    }
}