﻿namespace Ombi.Notifications.Agents
{
    public interface IPushoverNotification : INotification
    {
    }
}