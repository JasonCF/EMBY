﻿namespace Ombi.Notifications.Agents
{
    public interface ITelegramNotification : INotification
    {
    }
}