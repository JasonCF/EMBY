﻿namespace Ombi.Notifications.Agents
{
    public interface IDiscordNotification : INotification
    {
    }
}