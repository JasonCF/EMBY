﻿namespace Ombi.Notifications.Agents
{
    public interface IMattermostNotification : INotification
    {
    }
}