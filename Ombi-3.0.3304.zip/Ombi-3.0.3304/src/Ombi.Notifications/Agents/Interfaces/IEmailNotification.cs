﻿namespace Ombi.Notifications.Agents
{
    public interface IEmailNotification : INotification
    {
    }
}