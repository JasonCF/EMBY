﻿namespace Ombi.Api.Sonarr.Models
{
    public class Cutoff
    {
        public int id { get; set; }
        public string name { get; set; }
    }
}