﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ombi.Api.Sonarr.Models
{

    public class CommandResult
    {
        public string name { get; set; }
    }

}
