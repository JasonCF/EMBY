﻿namespace Ombi.Api.Sonarr.Models
{
    public class Item
    {
        public Quality quality { get; set; }
        public bool allowed { get; set; }
    }
}