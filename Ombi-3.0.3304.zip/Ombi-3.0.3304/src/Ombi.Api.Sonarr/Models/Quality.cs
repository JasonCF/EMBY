namespace Ombi.Api.Sonarr.Models
{
    public class Quality
    {
        public int id { get; set; }
        public string name { get; set; }
    }
}