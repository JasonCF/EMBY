﻿namespace Ombi.Api
{
    public enum ContentType
    {
        Json,
        Xml,
        Text,
        Html,
    }
}