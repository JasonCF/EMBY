﻿namespace Ombi.Helpers
{
    public class ApplicationSettings
    {
        public string OmbiService { get; set; }
    }
}