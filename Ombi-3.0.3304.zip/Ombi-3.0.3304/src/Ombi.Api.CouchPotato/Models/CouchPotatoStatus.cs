﻿namespace Ombi.Api.CouchPotato.Models
{
    public class CouchPotatoStatus
    {
        public bool success { get; set; }
    }
}