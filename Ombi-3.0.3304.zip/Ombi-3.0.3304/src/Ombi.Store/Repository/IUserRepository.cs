﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Ombi.Store.Entities;

namespace Ombi.Store.Repository
{
    //public interface IUserRepository
    //{
    //    Task CreateUser(User user);
    //    Task<User> GetUser(string username);
    //    Task<IEnumerable<User>> GetUsers();
    //    Task DeleteUser(User user);
    //    Task<User> UpdateUser(User user);
    //    Task<User> GetUser(int userId);
    //}
}