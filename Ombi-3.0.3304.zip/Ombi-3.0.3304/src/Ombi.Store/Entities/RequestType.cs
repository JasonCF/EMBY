﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ombi.Store.Entities
{
    public enum RequestType
    {
        TvShow,
        Movie
    }
}
