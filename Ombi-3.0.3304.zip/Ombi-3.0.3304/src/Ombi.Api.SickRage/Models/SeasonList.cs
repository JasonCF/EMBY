﻿using System.Collections.Generic;

namespace Ombi.Api.SickRage.Models
{
    public class SeasonList : SickRageBase<List<int>>
    {
        
    }
}