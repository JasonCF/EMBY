﻿namespace Ombi.Api.SickRage.Models
{
    public class SickRageTvAddData
    {
        public string name { get; set; }
    }

    public class SickRageTvAdd : SickRageBase<SickRageTvAddData>
    {
    }
}