﻿namespace Ombi.Api.SickRage.Models
{
    public static class SickRageStatus
    {
        public const string Wanted = "wanted";
        public const string Skipped = "skipped";
        public const string Ignored = "ignored";
    }
}