﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ombi.Api.Pushover.Models
{
    public class PushoverResponse
    {
        public int status { get; set; }
        public string request { get; set; }
    }
}
