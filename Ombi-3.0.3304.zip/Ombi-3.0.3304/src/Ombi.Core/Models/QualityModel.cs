﻿namespace Ombi.Core.Models
{
    public class QualityModel
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }
}