﻿namespace Ombi.Core.Rule.Interfaces
{
    public enum SpecificRules
    {
        CanSendNotification,
    }
}