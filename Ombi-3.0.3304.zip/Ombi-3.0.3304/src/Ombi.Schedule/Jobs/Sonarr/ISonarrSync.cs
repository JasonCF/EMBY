﻿using System.Threading.Tasks;

namespace Ombi.Schedule.Jobs.Sonarr
{
    public interface ISonarrSync : IBaseJob
    {
        Task Start();
    }
}