﻿using System.Threading.Tasks;

namespace Ombi.Schedule.Jobs.Couchpotato
{
    public interface ICouchPotatoSync : IBaseJob
    {
        Task Start();
    }
}