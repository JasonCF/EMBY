﻿using System.Threading.Tasks;

namespace Ombi.Schedule.Jobs.SickRage
{
    public interface ISickRageSync : IBaseJob
    {
        Task Start();
    }
}