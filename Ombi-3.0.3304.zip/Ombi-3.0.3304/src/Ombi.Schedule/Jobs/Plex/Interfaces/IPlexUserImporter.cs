﻿using System.Threading.Tasks;

namespace Ombi.Schedule.Jobs.Plex
{
    public interface IPlexUserImporter : IBaseJob
    {
        Task Start();
    }
}