﻿namespace Ombi.Schedule
{
    public interface IJobSetup
    {
        void Setup();
    }
}