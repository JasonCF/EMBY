﻿namespace Ombi.Api.Emby.Models
{
    public class EmbyUserLogin
    {
        public EmbyUser User { get; set; }
    }
}