﻿namespace Ombi.Api.Emby.Models
{
    public enum EmbyMediaType
    {
        Movie = 0,
        Series = 1,
        Music = 2,
        Episode = 3
    }
}