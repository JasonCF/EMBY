﻿namespace Ombi.Api.Emby.Models.Movie
{
    public class EmbyRemotetrailer
    {
        public string Url { get; set; }
        public string Name { get; set; }
    }
}