namespace Ombi.Api.Emby.Models.Movie
{
    public class EmbyChapter
    {
        public long StartPositionTicks { get; set; }
        public string Name { get; set; }
    }
}