﻿namespace Ombi.Api.Emby.Models.Media.Tv
{
    public class EmbyRemotetrailer
    {
        public string Url { get; set; }
        public string Name { get; set; }
    }
}