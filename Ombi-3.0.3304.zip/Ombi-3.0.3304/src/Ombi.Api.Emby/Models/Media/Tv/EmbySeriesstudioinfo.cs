namespace Ombi.Api.Emby.Models.Media.Tv
{
    public class EmbySeriesstudioinfo
    {
        public string Name { get; set; }
        public string Id { get; set; }
    }
}