﻿namespace Ombi.Api.Emby.Models.Movie
{
    public class EmbyImagetags
    {
        public string Primary { get; set; }
        public string Logo { get; set; }
        public string Thumb { get; set; }

        public string Banner { get; set; }
    }
}