namespace Ombi.Api.Emby.Models.Movie
{
    public class EmbyStudio
    {
        public string Name { get; set; }
        public string Id { get; set; }
    }
}