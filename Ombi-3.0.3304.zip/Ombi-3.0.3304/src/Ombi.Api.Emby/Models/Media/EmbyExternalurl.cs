﻿namespace Ombi.Api.Emby.Models.Movie
{
    public class EmbyExternalurl
    {
        public string Name { get; set; }
        public string Url { get; set; }
    }
}