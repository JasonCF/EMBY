﻿namespace Ombi.Api.Notifications.Models
{
    public class OneSignalNotificationResponse
    {
        public string id { get; set; }
        public int recipients { get; set; }
    }

}