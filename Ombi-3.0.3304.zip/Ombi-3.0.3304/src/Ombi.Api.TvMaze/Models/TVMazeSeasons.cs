﻿namespace Ombi.Api.TvMaze.Models
{
    public class TvMazeSeasons : TvMazeShow
    {
        public int number { get; set; }
    }
}