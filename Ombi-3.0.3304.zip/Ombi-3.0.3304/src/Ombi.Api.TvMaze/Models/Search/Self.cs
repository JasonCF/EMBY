﻿namespace Ombi.Api.TvMaze.Models
{
    public class Self
    {
        public string href { get; set; }
    }
}