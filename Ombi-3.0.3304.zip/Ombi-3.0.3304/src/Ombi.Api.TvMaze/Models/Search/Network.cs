﻿namespace Ombi.Api.TvMaze.Models
{
    public class Network
    {
        public Country country { get; set; }
        public int id { get; set; }
        public string name { get; set; }
    }
}