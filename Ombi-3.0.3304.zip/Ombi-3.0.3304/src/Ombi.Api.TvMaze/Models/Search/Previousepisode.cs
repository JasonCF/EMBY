﻿namespace Ombi.Api.TvMaze.Models
{
    public class Previousepisode
    {
        public string href { get; set; }
    }
}