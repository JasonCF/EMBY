﻿namespace Ombi.Api.TvMaze.Models
{
    public class Externals
    {
        public string imdb { get; set; }
        public int? thetvdb { get; set; }
        public int? tvrage { get; set; }
    }
}