﻿namespace Ombi.Api.TvMaze.Models
{
    public class Image
    {
        public string medium { get; set; }
        public string original { get; set; }
    }
}