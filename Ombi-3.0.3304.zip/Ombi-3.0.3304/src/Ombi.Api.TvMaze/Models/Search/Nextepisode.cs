﻿namespace Ombi.Api.TvMaze.Models
{
    public class Nextepisode
    {
        public string href { get; set; }
    }
}