﻿namespace Ombi.Api.TvMaze.Models
{
    public class Rating
    {
        public double? average { get; set; }
    }
}