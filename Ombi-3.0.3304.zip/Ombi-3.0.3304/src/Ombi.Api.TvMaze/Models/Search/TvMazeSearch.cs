﻿namespace Ombi.Api.TvMaze.Models
{
    public class TvMazeSearch
    {
        public double score { get; set; }
        public Show show { get; set; }
    }
}
