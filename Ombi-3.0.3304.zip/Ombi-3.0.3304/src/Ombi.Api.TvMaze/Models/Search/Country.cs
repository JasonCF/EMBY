﻿namespace Ombi.Api.TvMaze.Models
{
    public class Country
    {
        public string code { get; set; }
        public string name { get; set; }
        public string timezone { get; set; }
    }
}