﻿namespace Ombi.Api.TvMaze.Models
{
    public class Links
    {
        public Nextepisode nextepisode { get; set; }
        public Previousepisode previousepisode { get; set; }
        public Self self { get; set; }
    }
}