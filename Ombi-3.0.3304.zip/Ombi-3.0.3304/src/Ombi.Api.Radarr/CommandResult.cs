﻿using System;

namespace Ombi.Api.Radarr
{
    public class CommandResult
    {
        public string name { get; set; }
    }
}
