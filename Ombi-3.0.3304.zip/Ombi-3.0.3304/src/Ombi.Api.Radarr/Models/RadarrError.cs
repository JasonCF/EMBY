﻿namespace Ombi.Api.Radarr.Models
{
    public class RadarrError
    {
        public string message { get; set; }
    }

    public class RadarrErrorResponse
    {
        public string errorMessage { get; set; }
    }
}