﻿namespace Ombi.Api.Radarr.Models
{
    public class RadarrRootFolder
    {
        public int id { get; set; }
        public string path { get; set; }
        public long freespace { get; set; }
    }
}