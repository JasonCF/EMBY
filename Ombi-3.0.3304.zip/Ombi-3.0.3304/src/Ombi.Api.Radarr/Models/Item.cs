﻿namespace Ombi.Api.Radarr.Models
{
    public class Item
    {
        public Quality quality { get; set; }
        public bool allowed { get; set; }
    }
}