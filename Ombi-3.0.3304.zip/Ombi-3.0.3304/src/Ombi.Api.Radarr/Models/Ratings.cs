﻿namespace Ombi.Api.Radarr.Models
{
    public class Ratings
    {
        public int votes { get; set; }
        public double value { get; set; }
    }
}