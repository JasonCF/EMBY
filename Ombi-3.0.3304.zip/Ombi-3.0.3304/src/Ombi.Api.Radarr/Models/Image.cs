﻿namespace Ombi.Api.Radarr.Models
{
    public class Image
    {
        public string coverType { get; set; }
        public string url { get; set; }
    }
}